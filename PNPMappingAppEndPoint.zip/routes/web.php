<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Criminal_recordController;
use App\Http\Controllers\Offense_recordController;
use App\Http\Controllers\UserController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/
// get,. post, delete, updatew
Route::get('/', function () {
    return view('welcome');
})->name('sign_in_page');

Route::get('/admin', function(){
    return view();
})->middleware(['auth', 'role:admin'])->name('admin.index');

Route::post('/store' ,[Criminal_recordController::class, 'cstore'])->name('c_store');
Route::post('/ostore' ,[Offense_recordController::class, 'ostore'])->name('o_store');



Route::prefix("a")->name("a.")->group(function(){ // v- view
    Route::get('sign_in','UserController@sign_in')->name('sign_in');
    
    Route::get('add_new_record','UserController@add_new_record')->name('add_new_record');
    Route::get('add_crime_record_form','UserController@add_crime_record_form')->name('add_crime_record_form');
    Route::get('register','UserController@register')->name('register');
    Route::post('post_registration','UserController@post_registration')->name('post_registration');
    Route::post('post_log_in','UserController@post_log_in')->name('post_log_in');
    Route::get('sign_out','UserController@sign_out')->name('sign_out');
});


Route::prefix("v")->name("v.")->group(function(){ // v- view
    Route::get('dashboard','ScreenController@dashboard')->middleware(['auth'])->name('dashboard');
    Route::get('criminal_record','ScreenController@criminal_record')->name('criminal_record');
    Route::get('crimes_record','ScreenController@crimes_record')->name('crimes_record');
    Route::get('record','ScreenController@record')->name('record');
    Route::get('registration','ScreenController@registration')->name('registration');
    Route::get('log_in','ScreenController@log_in')->name('log_in');
    Route::get('map','ScreenController@map')->name('map');
    Route::get('add_criminal_record','ScreenController@add_criminal_record')->name('add_criminal_record');
    Route::get('add_offense_record','ScreenController@add_offense_record')->name('add_offense_record');
    Route::get('get_users','ScreenController@get_users')->name('get_users');
    Route::get('criminal_info','ScreenController@criminal_info')->name('criminal_info');
    Route::get('pnp_bensol_app','ScreenController@pnp_bensol_app')->name('pnp_bensol_app');
    Route::get('pdf_view','ScreenController@pdf_view')->name('pdf_view');

  
    //admin dashboard
    Route::get('admin_index','ScreenController@admin_index')->middleware(['auth', 'role:admin'])->name('admin_index');
});

Route::get('/select2_crinimal_name', [Offense_recordController::class, 'select2_crinimal_name'])->name('select2_crinimal_name');
Route::get('/get_map_info', [Offense_recordController::class, 'get_map_info'])->name('get_map_info');


Route::get('/crinimal_loc', [Offense_recordController::class, 'crinimal_loc'])->name('crinimal_loc');

Route::get('/create_record', [Criminal_recordController::class, 'createrecord'])->name('create_record');
Route::get('/get_criminal_record', [Criminal_recordController::class, 'get_criminal_record'])->name('get_criminal_record');
//
Route::get('/create_offense_record', [Offense_recordController::class, 'create_offense_record'])->name('create_offense_record');
Route::get('/get_criminal_offense_record', [Offense_recordController::class, 'get_criminal_offense_record'])->name('get_criminal_offense_record');
//
Route::get('create_offense_record_pdf', [Offense_recordController::class, 'create_offense_record_pdf'])->name('create_offense_record_pdf');
//
Route::get('/get_user', [UserController::class, 'get_user'])->name('get_user');
Route::delete('/destroy', [UserController::class, 'destroy'])->name('destroy');

