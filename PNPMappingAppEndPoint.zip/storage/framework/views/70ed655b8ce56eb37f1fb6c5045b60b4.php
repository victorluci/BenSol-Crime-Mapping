<!DOCTYPE html>
<html lang="en">
   
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Philippine National Police, Benito Soliven Mapping App</title>
</head>
<body>
    
    <div style="text-align: center;">
        <h1><b>Philippine National Police, Benito Soliven Mapping App</b></h1>

    </div>
    <div style="text-align: center;">
        <p style="font-size: 35px;">PNP Benito Soliven Mapping App, is an Application that collects Criminal Data from inside Benito Soliven Isabela.
             It is has an interactive map which collects data of longitude and latitude from the address inputs of crime records,
              and displays it in the map section, which enables the user to see information from the pinned location. Another feature is it displays 
            the offense data to the dashboard and display the crime each day, it also calculate whether the crime has increased or decreased.</p style="font-size: 35px;">
            <br>
            <br>
         <p style="font-size: 30px;">
            It has advantages compare to the manual system that the office is still using. Some advantages like, automatic crime counting and displaying it statistically,
            it has a map features, and a more secure environment.
         </p>
        
        </div>
        <br>
        <br>
        <br>
        <br>
        <br>
        <div style="text-align: center;">

            <h1>Goal:</h1>
            <p style="font-size: 20px;">
                To implement a more secure platform and give ease to the Philippine National Police
             </p>
        </div>
        <br>
        <br>
        <br>
        <div style="text-align: center;">
            <div class="d-flex justify-content-center py-4" style="text-align: center;">
                <h1>Here is what the application would look like</h1>
                <img src="<?php echo e(asset('images/ito8.png')); ?>" width="100px" alt="">
                <img src="<?php echo e(asset('images/ito1.png')); ?>" width="100px" alt="">
                <img src="<?php echo e(asset('images/ito2.png')); ?>" width="100px" alt="">
                <img src="<?php echo e(asset('images/ito3.png')); ?>" width="100px" alt="">
                <img src="<?php echo e(asset('images/ito4.png')); ?>" width="100px" alt="">
                <img src="<?php echo e(asset('images/ito5.png')); ?>" width="100px" alt="">
                <img src="<?php echo e(asset('images/ito6.png')); ?>" width="100px" alt="">
                <img src="<?php echo e(asset('images/ito7.png')); ?>" width="100px" alt="">
                
              </div>
              <br>
              <br>
              <br>
              <br>
              <p>Application Name:</p>
              <h1>PNP BenSol Mapping-APP</h1>
        </div>

</body>
</html><?php /**PATH C:\xampp\htdocs\PNPMappingEndpoint\resources\views/application_screen/pnp_bensol_app.blade.php ENDPATH**/ ?>