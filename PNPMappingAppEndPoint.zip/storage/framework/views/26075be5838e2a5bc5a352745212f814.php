

<?php $__env->startSection('css'); ?>
  <style type="text/css">
    .dataTables_length{
      display: none;
    }
    .dataTables_filter{
      margin-bottom: 10px;
      float: left !important;
    }
    .dataTables_filter label{
      width: 100%;
    }
  </style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('container'); ?>
<div class="pagetitle">
  <h1>User Management</h1>
  <!-- <nav>
    <ol class="breadcrumb">
      <li class="breadcrumb-item active">Criminal Records</li>
    </ol>
  </nav> -->
</div><!-- End Page Title -->
    <br>
    <div class="row mb-3">
      <div >
      <a href="<?php echo e(route('v.registration')); ?>" style="margin-right: 50px" type="submit"  class="btn btn-primary">Create User</a>
      </div>
    </div>
<section class="section dashboard">
   
    <div class="row">
        <table class="table" name = "user_table">
            <thead>
                <tr>
                    <th>Email</th>
                    <th>Date Crated</th>
                    <th>Action</th>
                    
                    
                    
                </tr>
            </thead>
            <tbody class="table-border-bottom-0">
            </tbody>
        </table>
  </div>
</section>




<?php $__env->stopSection(); ?>

<a class="float" href="<?php echo e(route('v.registration')); ?>">
    <i class="bx bxs-message-alt-add"></i>
  </a>
<?php $__env->startSection('js'); ?>

<script type="text/javascript">
  let offense_table =  $('table[name="user_table"]').DataTable({
      ajax: "<?php echo e(route('get_user')); ?>",
      responsive: true,
      orderBy: [[0, 'desc']],
      columns: [
        {data: 'email'},
        {data: 'created_at'},
        {data: function(data){
          return '<div class="btn" >\
                <form action="<?php echo e(url('/destroy')); ?>?id='+data.id+'" method="POST" type="button" class="btn btn-danger"><?php echo e(method_field('DELETE')); ?> <?php echo e(csrf_field()); ?> <button class="btn btn-danger ">Delete</button></form>\
                </div>';
        }}
       
      ]
  });
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PNPMappingEndpoint\resources\views/admin/UserManagement.blade.php ENDPATH**/ ?>