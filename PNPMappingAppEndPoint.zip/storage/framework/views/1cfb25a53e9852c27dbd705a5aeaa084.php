

<?php $__env->startSection('css'); ?>
  <style type="text/css">
    .dataTables_length{
      display: none;
    }
    .dataTables_filter{
      margin-bottom: 10px;
      float: left !important;
    }
    .dataTables_filter label{
      width: 100%;
    }
    .select2-container {
      width: 100% !important;
    }
  #map {
    position: relative; width: 370px; height: 360px
  }
 
  </style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('container'); ?>
<div class="pagetitle">
  <h1>Crime Record</h1>
  <!-- <nav>
    <ol class="breadcrumb">
      <li class="breadcrumb-item active">Criminal Records</li>
    </ol>
  </nav> -->
</div><!-- End Page Title -->

<section class="section dashboard">
    <div class="tab-pane fade profile-overview active show" id="profile-overview" role="tabpanel">
        
        <h5 class="card-title">Profile Details</h5>
        
        <div class="row">
            <div class="col-lg-3 col-md-4 label "><b>Full Name</b></div>
            <div class="col-lg-9 col-md-8"><?php echo e($record->first_name); ?> <?php echo e($record->middle_name); ?> <?php echo e($record->last_name); ?></div>
        </div>
        <br>
        <h5 class="card-title">About</h5>
        <p class="small fst-italic"><b>Gender:  </b> <?php echo e($record->gender); ?> </p>
        <p class="small fst-italic"><b>Age:  </b>  <?php echo e($record->age); ?></p>
        <p class="small fst-italic"><b>Weight:  </b>  <?php echo e($record->weight); ?></p>
        <p class="small fst-italic"><b>Height:  </b>  <?php echo e($record->height); ?></p>
        <p class="small fst-italic"><b>Birth Date:  </b>  <?php echo e($record->birth_date); ?></p>
        <p class="small fst-italic"><b>Address:  </b>  <?php echo e($record->address); ?></p>
    <br>
    <h5><b>Offenses</b></h5>
      
    <?php $__currentLoopData = $offenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p><b><?php echo e($offense->description); ?>:</b> <?php echo e($offense->created_at); ?></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</section>
<br>
<br>

<a class="btn btn-success" href="<?php echo e(route('create_offense_record_pdf')); ?>?id=<?php echo e($record->id); ?>">Export as PDF</a>
  
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>


<script type="text/javascript">
  

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\PNPMappingEndpoint\resources\views/application_screen/criminal_info.blade.php ENDPATH**/ ?>