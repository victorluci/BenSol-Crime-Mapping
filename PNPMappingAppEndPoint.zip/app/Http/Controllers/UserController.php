<?php

namespace App\Http\Controllers;
use DB;
use Session;
use DataTables;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use Illuminate\Validation\ValidationException;

class UserController extends Controller
{
    
    // public function sign_in(Request $request){
	// 	$data = $request->all();
    //     $request->validate([
    //         'email' => 'required',
    //         'password' => 'required',
            
    //     ]);

    //     $data['email'] = strip_tags($data['email']);
    //     $data['password'] = strip_tags($data['password']);
        

	// 	// $checkLogin = $request->only('email','password');
	// 	// if (Auth::attempt($checkLogin)){
	// 	// 	return redirect()->route('v.dashboard')->with([
	// 	// 		"message"=> "Successfully Registered"
	// 	// 	]);
	// 	// 	return redirect()->route('v.log_in')->withSuccess('Your Credentials are incorrect');
	// 	// }
		
    // }

	public function sign_out(){
		Session::flush();
		return redirect()->route('sign_in_page')->with(["message" => "Signed out successfully"]);
	}

	
	public function post_log_in(Request $request){
		$request->validate([
            'email' => 'required',
            'password' => 'required',
            
        ]);
		$checkLogin = $request->only('email','password');
		if (Auth::attempt($checkLogin)){
			// set session here
			$email = $checkLogin['email'];
			$password = $checkLogin['password'];
			$user =  DB::select("SELECT * FROM users WHERE email = '$email'");
			session(['user' => $user[0]]);
			return redirect()->route('v.dashboard')->with(["message" => "Successfully logged in"]);
		}
		return redirect('v/log_in')->with([
			"message" => "Your Credentials are incorrect",
		]);
	}
    // 	$email = $data['email'];
    // 	$password = $data['password'];

    // 	$user =  DB::select("SELECT * FROM users WHERE email = '$email'");
    // 	if($user){
    // 		$current_password =  $user[0]->password;
    // 		if($current_password == $password){
    // 			// user is authenticated
    // 			session(['user' => $user[0]]);
    //             return redirect()->route('v.dashboard');
    // 		}
    // 	}
    // 	throw ValidationException::withMessages(['sign_in_error' => "Unauthorized access is prohibited and punishable by the law"]);
    // }

	public function post_registration(Request $request){
		$data = $request->all();
		// dd($data);
		$data = $request->all();
        $request->validate([
			'name' => 'required',
            'email' => 'required',
            'password' => 'required',
            
        ]);
		$data['name'] = strip_tags($data['name']);
        $data['email'] = strip_tags($data['email']);
        $data['password'] = strip_tags($data['password']);
        

        $newrecord = User::create($data);
        return redirect()->route('v.get_users')-> with([
            "message"=> "Successfully Registered"
        ]); 
    }
	// 
	public function register(Request $request){
		return redirect()->route('v.registration');
	}
	// public function post_registration(Request $request){
	// 	$data = $request-all();
	// 	$request->validate([
	// 		'email'=> 'required|email|unique:table,column,except,id',
	// 		'password'=> 'required|min:7'
	// 	]);
	// 	$data = $request-all();
	// 	$createUser = $this->create($data);return redirect()->route('a.sign_in')-> with([
    //         "message"=> "You are now Registered"
    //     ]);
    // }
	// public function create(array $data){
	// 	return User::create(
	// 		[
	// 			'email' => $data['email'],
	// 			'password' => $data['password']
	// 		]
	// 		);
	// }
	public function get_user(Request $request){
		return DataTables::of(
            DB::select("SELECT * FROM users")
        )->make(true);
	}

	public function destroy(Request $request){
		User::find($request->id)->delete();
		return redirect()->back();
	}
	


}

