<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\CriminalRecord;
use App\Models\OffenseRecord; 

class ScreenController extends Controller
{
    //
    public function dashboard(){
        $record =  OffenseRecord::get_offense_record();
        $stat =  OffenseRecord::stat();
    	return view('application_screen.dashboard', compact('record','stat'));
    }
    
    public function criminal_info(Request $request){
        $data =  $request->all();
        $id =  $data['id'];
        $record = CriminalRecord::get_crime_record_by_id($id)[0];
        //get all offenses record for this particular criminal
        $offenses =  OffenseRecord::get_all_record_by_criminal_id($id);
        return view('application_screen.criminal_info', compact('record','offenses'));
    }

    public function criminal_record(){
        return view('application_screen.criminal_record');
    }
    
    public function crimes_record(){
        return view('application_screen.crimes_record');
    }
    
    public function record(){ 
        return view('application_screen.record');
    }
    
    public function add_criminal_record(){
        return view('application_screen.add_criminal_record');
    }
    public function add_offense_record(){
        return view('application_screen.add_offense_record');
    }
    public function registration(){
        return view('auth.registration');
    }
    public function log_in(){
        return view('welcome');
    }
    public function get_users(){
        return view('admin.UserManagement');
    }
    public function admin_index(){
        return view('admin.index');
    }
    public function map(){
        return view('application_screen.map');
    }
    public function pnp_bensol_app(){
        return view('application_screen.pnp_bensol_app');
    }
    public function pdf_view(Request $request){
        $data =  $request->all();
        $id =  $data['id'];
        $record = CriminalRecord::get_crime_record_by_id($id)[0];
        //get all offenses record for this particular criminal
        $offenses =  OffenseRecord::get_all_record_by_criminal_id($id);
        return view('application_screen.pdf', compact('record','offenses'));
     
    }
    




    // public function show(){
        //         $record = CriminalRecord::findOrFail($id);
        //         return view('v.view_record', compact('record'));
        //     }

        // public function view_table(){
        //     $data =  CriminalRecord::get_criminal_record();
        // 	return view('application_screen.criminal_record', compact('data'));
        // }
        
    }
