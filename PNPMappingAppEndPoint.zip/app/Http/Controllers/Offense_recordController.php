<?php

namespace App\Http\Controllers;

use DB;
use Storage;
use DataTables;
use Illuminate\Http\Request;
use App\Models\OffenseRecord;
use App\Models\CriminalRecord;
use Barryvdh\DomPDF\Facade\Pdf;


class Offense_recordController extends Controller
{
    public function ostore(Request $request)
    {
     
        $data = $request->all();
        $request->validate([
            'criminal_id' => 'required',
            'description' => 'required',
            // 'address' => 'required',
        ]);

        // $file = $data['image'];
        // $path = "images/criminal_image";
        // $file->move($path,$file->getClientOriginalName());
        // $image_location = $path."/".$file->getClientOriginalName();

        $data['criminal_id'] = strip_tags($data['criminal_id']);
        $data['description'] = strip_tags($data['description']);
        $data['address'] = strip_tags($data['barangay'])."...coordinates->". $data['long'].",".$data['lat'] ; 
        // $data['image_location'] = $image_location; 

        unset($data['long']);
        unset($data['lat']);
        unset($data['image']);
        // dd($data);
        // ->addColumn('action', function($row){
        //     $btn ='<a href="javascript:void(0)"data-toggle="tooltip"
        //      data-id="'.$row->id." data-original-title="Edit" class="edit btn btn-primary btn-sm editStudent"> Edit</a>';
        // });
        $newrecord = OffenseRecord::create($data);
        return redirect()->route('v.crimes_record')-> with([
            "message"=> "Record inserted successfully"
        ]); 
        
    }
    
    public function get_criminal_offense_record(){
        return DataTables::of(
            DB::select("SELECT a.*,
                CONCAT(b.first_name, ' ', b.middle_name, ' ',b.last_name) AS name
                FROM offense_record a 
                LEFT JOIN crime_record b ON b.id = a.criminal_id
                ORDER BY a.created_at DESC")
        )->make(true);
    }

    public function select2_crinimal_name(Request $request){
        $data =  $request->all();
        $q =  '';
        if(isset($data['q'])){
            $q = $data['q'];
        }
        return response()->json([
            "results" => CriminalRecord::select2_crinimal_name($q)
        ]);
    }

    public function get_map_info(){
        $info = DB::select(
                        "SELECT a.*,
                        b.gender, b.age, b.height, b.weight, b.birth_date,
                        CONCAT(b.first_name, ' ', b.middle_name, ' ',b.last_name) AS name
                        FROM offense_record a 
                        LEFT JOIN crime_record b ON b.id = a.criminal_id
                        ORDER BY a.created_at DESC
                        "
            );

        $container =  [];
        foreach($info as $row){
            $coordinates = explode(",", explode(">", $row->address)[1]);
            $long = $coordinates[0];
            $lat = $coordinates[1];
            $row->coordinates = [$long,$lat];
            array_push($container, $row);
        }
        return $container;
    }
    public function create_offense_record_pdf(Request $request){
        $id = $request->id;
        $record = CriminalRecord::get_crime_record_by_id($id)[0];
        $offenses =  OffenseRecord::get_all_record_by_criminal_id($id);
        $pdf = Pdf::loadView('application_screen.pdf', compact('record','offenses'));
        // return $pdf->stream();

        return $pdf->download();
    }

}
