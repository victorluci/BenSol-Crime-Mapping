<?php

namespace App\Http\Controllers;

use DB;
use Storage;
use DataTables;
use Illuminate\Http\Request;
use App\Models\CriminalRecord;

class Criminal_recordController extends Controller
{
   public function cstore(Request $request){
        $data =  $request->all();
        $request->validate([
            'first_name' => 'required',
            'middle_name' => 'required',
            'last_name' => 'required',
            'gender' => 'required',
            'age' => 'required|numeric',
            'weight' => 'required',
            'height' => 'required',
            'description' => 'required'
        ]);

        // $offense = OffenseRecord::get();
        // if ($request->ajax()){
        //     // return datatables()->of(OffenseRecord::select(*))
        //     $allData = DataTables::of($offense)
        //     ->addCollumn('action', 'crimes_action')
        //     ->rawCollumns(['action'])
        //     ->addIndexColumn()
        //     ->make(true);

        // }

        
        // $file = $data['image'];
        // $path = "images/criminal_image";
        // $file->move($path,$file->getClientOriginalName());
        // $image_location = $path."/".$file->getClientOriginalName();

        
        $data['first_name'] = strip_tags($data['first_name']);
        $data['middle_name'] =   strip_tags($data['middle_name']);
        $data['last_name'] =   strip_tags($data['last_name']);
        $data['gender'] = strip_tags($data['gender']);
        // $data['image_location'] = $image_location; 
        $data['address'] = strip_tags($data['barangay'])."...coordinates->". $data['long'].",".$data['lat'] ; 
        $data['age'] = strip_tags($data['age']);
        $data['birth_date'] = strip_tags($data['birthday']);
        $data['weight'] = strip_tags($data['weight']);
        $data['height'] = strip_tags($data['height']);
        $data['description'] = strip_tags($data['description']);
        // remove unwanted data from var $data
        unset($data['_token']);
        unset($data['_method']);
        unset($data['image']);
        unset($data['birthday']);
        unset($data['long']); // remove this upon finishing the TODO 1 
        unset($data['lat']); // remove this upon finishing the TODO 1
        // dd($data);
        $newrecord = CriminalRecord::create($data);
        return redirect()->route('v.criminal_record')->with([
            "message" => "Record inserted successfully"
        ]);
    }
    
    public function get_criminal_record(){
        return DataTables::of(
            DB::select("SELECT * FROM crime_record")
        )->make(true);
    }
    // public function show(){
    //     $record = CriminalRecord::findOrFail($id);
    //     return view('v.view_record', compact('record'));
    // }
    
}

