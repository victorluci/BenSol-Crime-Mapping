@extends('layout.master')

@section('css')
  <style type="text/css">
    .dataTables_length{
      display: none;
    }
    .dataTables_filter{
      margin-bottom: 10px;
      float: left !important;
    }
    .dataTables_filter label{
      width: 100%;
    }
  </style>
@endsection
<link href="https://cdn.datatables.net/1.13.7/css/jquery.dataTables.min.css" rel="stylesheet" >

@section('container')
<div class="pagetitle">
  <h1>Crime Record</h1>
  <!-- <nav>
    <ol class="breadcrumb">
      <li class="breadcrumb-item active">Criminal Records</li>
    </ol>
  </nav> -->
</div><!-- End Page Title -->
<br>
<div class="row mb-3">
  <div >
  <a href="{{ route('v.add_offense_record') }}" style="margin-right: 50px" type="submit"  class="btn btn-primary">Add record</a>
  </div>
</div>
    
<section class="section dashboard">
  <div class="row">
    <table class="table" name = "offense_table">
        <thead>
        <tr>
            <th>Name</th>
            <th>Description</th>
            <th>Address</th>
            <th>Date</th>
            {{-- <th>Action</th> --}}
            

        </tr>
        </thead>
        <tbody class="table-border-bottom-0">
        </tbody>
    </table>
  </div>
</section>

<a class="float" href="{{route('v.add_offense_record')}}">
  <i class="bx bxs-message-alt-add"></i>
</a >


@endsection


@section('js')
{{-- <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
<script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script> --}}
<script type="text/javascript">
  let offense_table =  $('table[name="offense_table"]').DataTable({
      ajax: "{{route('get_criminal_offense_record')}}",
      responsive: true,
      orderBy: [[0, 'desc']],
      columns: [
        {data: 'name', name:'name'},
        {data: 'description' , name:'description'},
        {data: 'address' , name:'address'},  
        {data: 'created_at' , name:'created_at'},
        // {data: 'action' , name:'action'},
      ]
  });
</script>

@endsection