<a href="" data-toggle="tooltip" class="edit btn btn-succes edit">Edit</a>
<a href="" id="delete-company" class="delete btn btn-danger">Delete</a>