{{-- @extends('layout.master')

@section('container')
<div class="pagetitle">
  <h1>View Crimes</h1>
 <!--  <nav>
    <ol class="breadcrumb">
      <li class="breadcrumb-item"><a href="index.html">Home</a></li>
      <li class="breadcrumb-item active">Dashboard</li>
    </ol>
  </nav> -->
</div><!-- End Page Title -->
    
<section class="section dashboard">
      <div class="row">

        

        <div class="col-lg-12">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Details<span></span></h5>

              <div class="activity">

                @php
                    // dd($record);
                @endphp
                @foreach ($record as $row)
                  <div class="activity-item d-flex">
                    <div class="activite-label">{{$row->created_at}}</div>
                    <i class='bi bi-circle-fill activity-badge text-warning align-self-start'></i>
                    <div class="activity-content">
                      {{$row->description}}
                    </div>
                  </div>
                @endforeach

                

              </div>

            </div>
          </div>
        </div>

      </div>
    </section>
@endsection --}}