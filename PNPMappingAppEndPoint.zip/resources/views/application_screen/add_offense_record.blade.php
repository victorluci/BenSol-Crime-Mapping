@extends('layout.master')

@section('css')
  <style type="text/css">
    .dataTables_length{
      display: none;
    }
    .dataTables_filter{
      margin-bottom: 10px;
      float: left !important;
    }
    .dataTables_filter label{
      width: 100%;
    }
    .select2-container {
      width: 100% !important;
    }
  #map {
    position: relative; width: 370px; height: 360px
  }
 
  </style>
@endsection


@section('container')
<div class="pagetitle">
  <h1>Crime Record</h1>
  <!-- <nav>
    <ol class="breadcrumb">
      <li class="breadcrumb-item active">Criminal Records</li>
    </ol>
  </nav> -->
</div><!-- End Page Title -->

<section class="section dashboard">
    <div class="row">
        <form name = "create_offense_record" method="POST" action="{{route('o_store')}}"  enctype="multipart/form-data">
            @csrf
            @method('post')
          <div class="row mb-3">
            <label for="inputText" class="col-sm-2 col-form-label">Criminal</label>
            <div class="col-sm-10">
              <select name="criminal_id" ></select>
            </div>
          </div>

          {{-- <div class="row mb-3">
            <label for="inputNumber" class="col-sm-2 col-form-label">Image</label>
            <div class="col-sm-10">
              <input class="form-control" type="file" name="image" >
              @error('image')
              <span class="error_message">{{$message}}</span>
              @enderror
            </div>
          </div> --}}

          <div class="row mb-3">
            <label for="inputPassword" class="col-sm-2 col-form-label">Description</label>
            <div class="col-sm-10">
              <textarea class="form-control" style="height: 100px" name="description" >{{old('description')}}</textarea>
              @error('description')
              <span class="error_message">{{$message}}</span>
              @enderror
            </div>
          </div>

          <div class="row mb-3">
            <label for="inputDate" class="col-sm-2 col-form-label">Date</label>
            <div class="col-sm-10">
              <input type="date" class="form-control" name="date" value="{{old('date')}}">
              @error('date')
              <span class="error_message">{{$message}}</span>
              @enderror
            </div>
          </div>

          <div class="row mb-3">
            <label for="inputDate" class="col-sm-2 col-form-label">Time</label>
            <div class="col-sm-10">
              <input type="time" class="form-control" name="time" value="{{old('time')}}">
              @error('time')
              <span class="error_message">{{$message}}</span>
              @enderror
            </div>
          </div>
          
          <div class="row mb-3">
            <label for="inputDate" class="col-sm-2 col-form-label" name="address" >Address</label>
            <input type="text" class="form-control" name="barangay" style="margin-bottom: 5px" value="{{old('address')}}">
            @error('barangay')
          <span class="error_message">{{$message}}</span>
      @enderror
            <input name="long"  value="" hidden>
            <input name="lat"  value="" hidden>
            <div class="col-sm-10">
              <div id="map" class="mb-2"></div >
                <pre id="coordinates" class="coordinates"></pre>
              
            </div>
          </div>

           <div class="row mb-3">
            <div class="col-sm-10">
              <button type="submit"  class="btn btn-primary">Add record</button>
            </div>
          </div>

        </form>
      </div>
  </section>
  
@endsection


@section('js')


{{-- <script src="https://api.mapbox.com/mapbox-gl-js/v2.15.0/mapbox-gl.js"></script> --}}
<link href="https://api.mapbox.com/mapbox-gl-js/v3.0.0/mapbox-gl.css" rel="stylesheet">
<script src="https://api.mapbox.com/mapbox-gl-js/v3.0.0/mapbox-gl.js"></script>
<script type="text/javascript">
    mapboxgl.accessToken = 'pk.eyJ1IjoidmljdG9yaW5vaSIsImEiOiJjbGtnbDgxbjYwMWxyM2VueTZzbzdjMG9xIn0.cDWO9uV_3oq2AlHuIWQzfw';
    
    
    const map = new mapboxgl.Map({
        container: 'map',
        style: 'mapbox://styles/mapbox/satellite-v9',
        center: [121.96411729520872,16.983473280532046],
        zoom: 14
       
    });

    
    const marker = new mapboxgl.Marker({
        draggable: true
    }).setLngLat([121.96411729520872, 16.983473280532046]).addTo(map);
    
    function onDragEnd() {
        const lngLat = marker.getLngLat();
        $('input[name="long"]').val(lngLat.lng);
        $('input[name="lat"]').val(lngLat.lat);
    }
    marker.on('dragend', onDragEnd);
 

$("select[name='criminal_id']").select2({
  ajax: {
    url: "{{route('select2_crinimal_name')}}",
    dataType: 'json',
    delay: 250,
    data: function (params) {
      return {
        q: params.term, // search term
        page: params.page
      };
    },
    processResults: function (data, params) {
      params.page = params.page || 1;

      return {
        results: data.results,
        pagination: {
          more: (params.page * 30) < data.total_count
        }
      };
    },
    cache: true
  },
  placeholder: 'Search for criminal',
  templateResult: formatRepo,
  templateSelection: formatRepoSelection
});

function formatRepo (repo) {
  if (repo.loading) {
    return repo.text;
  }

  return repo.text;;
}

function formatRepoSelection (repo) {
  return repo.text;
}



</script>

@endsection
