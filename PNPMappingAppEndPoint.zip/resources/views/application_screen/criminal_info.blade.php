@extends('layout.master')

@section('css')
  <style type="text/css">
    .dataTables_length{
      display: none;
    }
    .dataTables_filter{
      margin-bottom: 10px;
      float: left !important;
    }
    .dataTables_filter label{
      width: 100%;
    }
    .select2-container {
      width: 100% !important;
    }
  #map {
    position: relative; width: 370px; height: 360px
  }
 
  </style>
@endsection


@section('container')
<div class="pagetitle">
  <h1>Crime Record</h1>
  <!-- <nav>
    <ol class="breadcrumb">
      <li class="breadcrumb-item active">Criminal Records</li>
    </ol>
  </nav> -->
</div><!-- End Page Title -->

<section class="section dashboard">
    <div class="tab-pane fade profile-overview active show" id="profile-overview" role="tabpanel">
        
        <h5 class="card-title">Profile Details</h5>
        
        <div class="row">
            <div class="col-lg-3 col-md-4 label "><b>Full Name</b></div>
            <div class="col-lg-9 col-md-8">{{$record->first_name}} {{$record->middle_name}} {{$record->last_name}}</div>
        </div>
        <br>
        <h5 class="card-title">About</h5>
        <p class="small fst-italic"><b>Gender:  </b> {{$record->gender}} </p>
        <p class="small fst-italic"><b>Age:  </b>  {{$record->age}}</p>
        <p class="small fst-italic"><b>Weight:  </b>  {{$record->weight}}</p>
        <p class="small fst-italic"><b>Height:  </b>  {{$record->height}}</p>
        <p class="small fst-italic"><b>Birth Date:  </b>  {{$record->birth_date}}</p>
        <p class="small fst-italic"><b>Address:  </b>  {{$record->address}}</p>
    <br>
    <h5><b>Offenses</b></h5>
      
    @foreach ($offenses as $offense)
        <p><b>{{$offense->description}}:</b> {{$offense->created_at}}</p>
    @endforeach
</section>
<br>
<br>

<a class="btn btn-success" href="{{route('create_offense_record_pdf')}}?id={{$record->id}}">Export as PDF</a>
  
@endsection


@section('js')


<script type="text/javascript">
  

</script>

@endsection
