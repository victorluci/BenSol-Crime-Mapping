<html>
    @php
        // dd($record);
    @endphp
    <h1 >{{$record->first_name}} {{$record->middle_name}}.{{$record->last_name}}</h1>
    <br>
    <h2>About</h2>
    <p><b>Gender: </b>{{$record->gender}}</p>
    <p><b>Age: </b>{{$record->age}}</p>
    <p><b>Weight: </b>{{$record->weight}}</p>
    <p><b>Height: </b>{{$record->height}}</p>
    <p><b>Birth Date: </b>{{$record->birth_date}}</p>
    <p><b>Address: </b>{{$record->address}}</p>
    <br>
    <br>
    <h2>Offences</h2> 
    @foreach ($offenses as $data)
    <p><b>{{$data->description}}: </b>{{$data->created_at}}</p>
    @endforeach
 


  
    

</html>