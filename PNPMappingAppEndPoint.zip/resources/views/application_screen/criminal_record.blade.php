@extends('layout.master')

@section('css')
  <style type="text/css">
    .dataTables_length{
      display: none;
    }
    .dataTables_filter{
      margin-bottom: 10px;
      float: left !important;
    }
    .dataTables_filter label{
      width: 100%;
    }
  </style>
@endsection


@section('container')
<div class="pagetitle">
  <h1>Criminal Record</h1>
  <!-- <nav>
    <ol class="breadcrumb">
      <li class="breadcrumb-item active">Criminal Records</li>
    </ol>
  </nav> -->
</div><!-- End Page Title -->
<br>
<div class="row mb-3">
  <div >
  <a href="{{ route('v.add_criminal_record') }}" style="margin-right: 50px" type="submit"  class="btn btn-primary">Add record</a>
  </div>
</div>
    
<section class="section dashboard">
  <div class="row">
    <table class="table" name = "criminal_table">
        <thead>
          <tr>
              <th>First Name</th>
              <th>Middle Name</th>
              <th>Last Name</th>
              <th>Gender</th>
              <th>Age</th>
              <th>Weight</th>
              <th>Height</th>
              <th>Birth Date</th>
              <th>Address</th>
              <th>Description</th>
              <th>Date</th>
              <th>Action</th>
          </tr>
        </thead>
        <tbody class="table-border-bottom-0">
        </tbody>
    </table>
  </div>
</section>

<a class="float" href="{{route('v.add_criminal_record')}}">
  <i class="bx bxs-message-alt-add"></i>
</a>


@endsection

{{-- 
<tbody>+
  @if ($data-> count()>0)
  @foreach ($data as $rs )
  <tr>
    <td>{{$rs->first_name}}</td>
  </tr>
    
  @endforeach
    
  @endif
</tbody> --}}

@section('js')

<script type="text/javascript">
  let criminal_table =  $('table[name="criminal_table"]').DataTable({
      ajax: "{{route('get_criminal_record')}}",
      responsive: true,
      orderBy: [[0, 'desc']],
      columns: [
        {data: 'first_name'},
        {data: 'middle_name'},
        {data: 'last_name'},
        {data: 'gender'},
        {data: 'age'},
        {data: 'weight'},
        {data: 'height'},
        {data: 'birth_date'},
        {data: 'address'},
        {data: 'description'},
        {data: 'created_at'},
        {data: function(data){
          return '<div class="btn" type="button">\
                  <a href="{{route("v.criminal_info")}}?id='+data.id+'" type="button" class="btn.btn" ><button class="btn btn-info">View</button></a>\
                </div>';
        }}
  ]
  });
</script>


@endsection