@extends('layout.master')

@section('css')
  <style type="text/css">
   .dataTables_length{
      display: none;
    }
    .dataTables_filter{
      margin-bottom: 10px;
      float: left !important;
    }
    .dataTables_filter label{
      width: 100%;
    }

	  #map { position: absolute; width: 100%; height: 100% }

    @media (max-width: 1199px){
        #main {
          padding: 0px !important;
      }
    }
  </style>
@endsection


@section('container')
<div class="pagetitle">
  <h1>View Map</h1>
  <!-- <nav>
    <ol class="breadcrumb">
      <li class="breadcrumb-item active">Criminal Records</li>
    </ol>
  </nav> -->
</div><!-- End Page Title -->

<section class="section dashboard">
   
          
<div class="mt-3" style="height: 500px">
  <div id="map" ></div >
</div>

</section>
@endsection


@section('js')
{{-- <meta name="viewport" content="initial-scale=1,maximum-scale=1,user-scalable=no"> --}}
{{-- <link href="https://api.mapbox.com/mapbox-gl-js/v3.0.0/mapbox-gl.css" rel="stylesheet">
<script src="https://api.mapbox.com/mapbox-gl-js/v1.8.0/mapbox-gl.js"></script> --}}
<link href="https://api.mapbox.com/mapbox-gl-js/v3.0.0/mapbox-gl.css" rel="stylesheet">
<script src="https://api.mapbox.com/mapbox-gl-js/v3.0.0/mapbox-gl.js"></script>
<script type="text/javascript">
    mapboxgl.accessToken = 'pk.eyJ1IjoidmljdG9yaW5vaSIsImEiOiJjbGtnbDgxbjYwMWxyM2VueTZzbzdjMG9xIn0.cDWO9uV_3oq2AlHuIWQzfw';
    
    const map = new mapboxgl.Map({
        container: 'map',
        style: 'mapbox://styles/mapbox/outdoors-v12',
        // center: [121.95711729520872,16.983473280532046],
        center: [121.92730558660759,  16.930249396899015],
        zoom: 10.7
	
    });

    
    var process_pin_render = () =>{
      $.ajax({
        url: "{{route('get_map_info')}}",
        success: function(e){
          console.log(e);
          for(let key in e){
            var pin = { color: "#47cc6b" };
            var marker = new mapboxgl.Marker(pin)
              .setLngLat(e[key].coordinates)
              .setPopup(
                new mapboxgl.Popup() // add popups
                .setHTML('<div class="tab-pane fade profile-overview active show" id="profile-overview" role="tabpanel">\
                            <h5 class="card-title">About</h5>\
                            <p class="small fst-italic">'+e[key].description+'</p>\
\
                            <h5 class="card-title">Profile Details</h5>\
\
                            <div class="row">\
                              <div class="col-lg-3 col-md-4 col-sm-6 label ">Full Name</div>\
                              <div class="col-lg-9 col-md-8 col-sm-6"><b>'+e[key].name+'</b></div>\
                            </div>\
\
                            <div class="row">\
                              <div class="col-lg-3 col-md-4 col-sm-6 label ">Coordinates</div>\
                              <div class="col-lg-9 col-md-8 col-sm-6"><b>'+e[key].coordinates+'</b></div>\
                            </div>\
\
                            <div class="row">\
                              <div class="col-lg-3 col-md-4 col-sm-6 label ">Created At</div>\
                              <div class="col-lg-9 col-md-8 col-sm-6"><b>'+e[key].created_at+'</b></div>\
                            </div>\
\
                            <div class="row">\
                              <div class="col-lg-3 col-md-4 col-sm-6 label ">Gender</div>\
                              <div class="col-lg-9 col-md-8 col-sm-6"><b>'+e[key].gender+'</b></div>\
                            </div>\
\
                            <div class="row">\
                              <div class="col-lg-3 col-md-4 col-sm-6 label ">Height in cm</div>\
                              <div class="col-lg-9 col-md-8 col-sm-6"><b>'+e[key].height+'</b></div>\
                            </div>\
\
                            <div class="row">\
                              <div class="col-lg-3 col-md-4 col-sm-6 label ">Weight in kg</div>\
                              <div class="col-lg-9 col-md-8 col-sm-6"><b>'+e[key].weight+'</b></div>\
                            </div>\
\
                          </div>')
              )
              .addTo(map);
              
              // marker._element.id = e[key].call_sign;
              // markers.push(marker);
          }
        },
        error: function(e){
          console.log(e);
        }
      });
  }
  process_pin_render();
  map.on('load', () => {
// Add a data source containing GeoJSON data.
map.addSource('maine', {
'type': 'geojson',
'data': {
'type': 'Feature',
'geometry': {
'type': 'Polygon',
// These coordinates outline Maine.
'coordinates': [
[
[121.93125458885584,  17.032460506574395],
[121.94173577374943,  17.02035083931267],
[121.9303811567816,  17.003646564377874],
[121.94521483676249,  16.976902535159397],
[121.93779066412986,  16.971054853201352],
[121.93080320753529,  16.972307943241987],
[121.92337903490449,  16.973143331955626],
[121.91770172642049,  16.97523178747484],
[121.8967165021246,  16.97592786476845],
[121.85974387264736,  16.97693819461692],
[121.84125755791086,  16.983000059479764],
[121.84495482085731,  16.969865771475824],
[121.84759572296366,  16.96127747094033],
[121.85815933138514,  16.96228787962147],
[121.8623847747537,  16.953194005871765],
[121.86713839854241,  16.943594439558936],
[121.87823018738595,  16.947636421956034],
[121.88773743496535,  16.943594439558936],
[121.90041376507105,  16.93702603288766],
[121.91203373433473,  16.935004938542406],
[121.90675195077574,  16.931973326935903],
[121.9056955899336,  16.926415116033667],
[121.91309011582865,  16.92388860228293],
[121.92206918298785,  16.928941595880133],
[121.92682280677656,  16.927425712041014],
[121.92682280677656,  16.920351426081012],
[121.92312554383005,  16.9168141834476],
[121.92312554383005,  16.905696702824997],
[121.92365372425013,  16.89963234610012],
[121.93368915225159,  16.89457856652237],
[121.9337454080785,  16.88518660323173],
[121.94208502717379,  16.88518660323173],
[121.95250955104291,  16.884521594779827],
[121.95545337818692,  16.87813286843658],
[121.91937755493524,  16.870419938231933],
[121.90287823488387,  16.856808027629683],
[121.89985591755163,  16.85352507735179],
[121.89985591755163,  16.83756155451779],
[121.8970760445199,  16.82026621907606],
// [121.90819553664693,  16.811617959363645],
[121.90174035074244,  16.813243332097016],
[121.90819553664693,  16.789662913721045],
[121.95962318773456,  16.8062957573311],
[121.97074267986301,  16.82026621907606],
[121.97699739418448,  16.797646860563873],
// [122.00827096579184,  16.814944259786174],
[121.99728274224128,  16.819536437442437],
[121.99842335523101,  16.85652488024111],
[121.99147367265158,  16.90440660012345],
[121.98313405355628,  16.93166714875619],
[121.98660889484597,  16.980194447246006],
[121.98104914878246,  17.01143141275682],
[121.98104914878246,  17.022064085203965],
[121.98029211632411,  17.02569286613121],
[121.9765749723341,  17.031419045635445],
[121.96852116035711,  17.038132274222605],
[121.96067385638065,  17.03951437960015],
[121.9299041644689,  17.03892204997544],



]
]
}
}
});
 
// Add a new layer to visualize the polygon.
map.addLayer({
'id': 'maine',
'type': 'fill',
'source': 'maine', // reference the data source
'layout': {},
'paint': {
'fill-color': '#0080ff', // blue color fill
'fill-opacity': 0.5
}
});
// Add a black outline around the polygon.
map.addLayer({
'id': 'outline',
'type': 'line',
'source': 'maine',
'layout': {},
'paint': {
'line-color': '#000',
'line-width': 3
}
});
});


</script>

@endsection