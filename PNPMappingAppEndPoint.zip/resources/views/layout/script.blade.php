<!-- Vendor JS Files -->
  <script src="{{asset('admintemplate/assets/vendor/apexcharts/apexcharts.min.js')}}"></script>
  <script src="{{asset('admintemplate/assets/vendor/bootstrap/js/bootstrap.bundle.min.js')}}"></script>
  <script src="{{asset('admintemplate/assets/vendor/chart.js/chart.umd.js')}}"></script>
  <script src="{{asset('admintemplate/assets/vendor/echarts/echarts.min.js')}}"></script>
  <script src="{{asset('admintemplate/assets/vendor/quill/quill.min.js')}}"></script>
  <script src="{{asset('admintemplate/assets/vendor/simple-datatables/simple-datatables.js')}}"></script>
  <script src="{{asset('admintemplate/assets/vendor/tinymce/tinymce.min.js')}}"></script>
  <script src="{{asset('admintemplate/assets/vendor/php-email-form/validate.js')}}"></script>

  <script src="{{asset('admintemplate/assets/js/main.js')}}"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
  <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
  <script src="{{asset('select2/dist/js/select2.min.js')}}"></script>