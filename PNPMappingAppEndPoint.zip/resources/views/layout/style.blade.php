<meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="{{asset('admintemplate/assets/vendor/bootstrap/css/bootstrap.min.css')}}" rel="stylesheet">
  <link href="{{asset('admintemplate/assets/vendor/bootstrap-icons/bootstrap-icons.css')}}" rel="stylesheet">
  <link href="{{asset('admintemplate/assets/vendor/boxicons/css/boxicons.min.css')}}" rel="stylesheet">
  <link href="{{asset('admintemplate/assets/vendor/quill/quill.snow.css')}}" rel="stylesheet">
  <link href="{{asset('admintemplate/assets/vendor/quill/quill.bubble.css')}}" rel="stylesheet">
  <link href="{{asset('admintemplate/assets/vendor/remixicon/remixicon.css')}}" rel="stylesheet">
  <link href="{{asset('admintemplate/assets/vendor/simple-datatables/style.css')}}" rel="stylesheet">
  <link href="{{asset('select2/dist/css/select2.min.css')}}" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="{{asset('admintemplate/assets/css/style.css')}}" rel="stylesheet">
  <link href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css" rel="stylesheet">


  <style type="text/css">
    .float{
            cursor: pointer;
            position:fixed;
            width:60px;
            height:60px;
            bottom:20px;
            right:20px;
            background-color:rgb(255, 255, 255);
            color:#000000;
            border-radius:50px;
            box-shadow: 2px 2px 3px #999;
            display: flex;
            justify-content: center;
            align-items: center;
        }
    span.error_message{
      color: red;
    }
    #map { position: relative; top: 0; bottom: 0; width: 100%; }

    .coordinates {
      background: rgba(0, 0, 0, 0.5);
      color: #fff;
      position: absolute;
      bottom: 40px;
      left: 10px;
      padding: 5px 10px;
      margin: 0;
      font-size: 11px;
      line-height: 18px;
      border-radius: 3px;
      display: none;
    }
  </style>