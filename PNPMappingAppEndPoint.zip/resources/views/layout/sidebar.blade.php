<!-- ======= Sidebar ======= -->
  <aside id="sidebar" class="sidebar">
    <ul class="sidebar-nav" id="sidebar-nav">
      <li class="nav-item">
        <a class="nav-link " href="{{route('v.dashboard')}}">
          <i class="bi bi-grid"></i>
          <span>Dashboard</span>
        </a>
      </li><!-- End Dashboard Nav -->
      <li class="nav-item">
        <a class="nav-link " href="{{route('v.criminal_record')}}">
          <i class="bx bx-user-x"></i>
          <span>Criminal Record</span>
        </a>
      </li><!-- End Dashboard Nav -->
      <li class="nav-item">
        <a class="nav-link " href="{{route('v.crimes_record')}}">
          <i class="bx bx-user-minus"></i>
          <span>Offense Record</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link " href="{{route('v.map')}}">
          <i class="bi bi-map"></i>
          <span>View Map</span>
        </a>
      </li>
      @if(session('user')->role == 1)
        <li class="nav-item">
          <a class="nav-link " href="{{route('v.get_users')}}">
            <i class="bi bi-person-add"></i>
            <span>Administrator</span>
          </a>
        </li>
      @endif    
      <!-- End Dashboard Nav -->
    </ul>
  </aside><!-- End Sidebar-->