<!DOCTYPE html>
<html lang="en">

<head>
  @include('layout.style')
  @yield('css')
</head>

<body>

  @include('layout.topbar')
  @include('layout.sidebar')

  <main id="main" class="main">
    @yield('container')
  </main><!-- End #main -->

  

  @include('layout.script')
  @yield('js')

</body>

</html>